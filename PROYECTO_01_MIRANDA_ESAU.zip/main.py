from codigo import top_busqueda
from codigo import top_ventas
from codigo import venta_x_cat
from codigo import busqueda_x_cat
from codigo import score_x_id_ord
from codigo import sin_score
from codigo import worst_score
from codigo import venta_x_mes
from codigo import venta_anual

usuario_clave=[['Esau','helios'],['Javier','emtech']]

usuario = input('Ingresa tu usuario: ')
contraseña = input('Ingresa tu contraseña: ')

acess=0
for claves in usuario_clave:
  if claves[0] == usuario and claves[1] == contraseña:
    acess=1

if acess == 1:
  print('\n')
  print('Bienvenido a Lifestore Report')
  print('\n')
else:
  print('\n')
  print('Usuario y/o clave incorrecta')
  print('\n')
  
if acess == 1:
  opcion = input('Eliga el número del reporte que desea ver:\n 1.- Productos más vendidos y productos rezagados, \n 2.- Productos por reseña en el servicio, \n 3.- Total de ingresos y ventas promedio mensuales, total anual y meses con más ventas al año. \n ')

if opcion == '1':
  print('\n')
  inciso = input('Eliga el inciso que desea ver:\n a.- Los 10 productos con mayor venta y 10 productos más buscados, \n b.- Por categoría, los 10 productos con menor venta y 10 productos menos buscados.  \n')
  print('\n')

  if inciso == 'a':
    print('Los 10 productos con mayor venta son:\n')
    for producto in top_ventas[:10]:
      print('"',producto[1],'" tiene',producto[-2],'ventas.')
    print('\n')
    print('Los 10 productos con más busquedas son:\n')
    for producto in top_busqueda[:10]:
      print('"',producto[1],'" tiene',producto[-1],'busquedas.')

  elif inciso == 'b':
    for i in range(len(venta_x_cat)):
      print('Para "',venta_x_cat[i][1][-4],'", los productos con menos ventas son: \n')
      for producto in venta_x_cat[i][-10:]:
        print('"',producto[1],'" tiene',producto[-2],'ventas.')
      print('\n')
    for i in range(len(busqueda_x_cat)):
      print('Para "',busqueda_x_cat[i][1][-4],'", los productos con menos busquedas son: \n')
      for producto in busqueda_x_cat[i][-10:]:
        print('"',producto[1],'" tiene',producto[-1],'busquedas.')
      print('\n')  

  else:
    print('opción incorrecta')

elif opcion == '2':
  print('Los 20 productos con mejor reseña son: \n')
  # print(len(score_x_id_ord))
  for score in score_x_id_ord[:10]:
    print('"',score[-1],'" tiene un score promedio de:',score[1])
  print('\n')
  print('Los 20 productos con peor reseña son: \n')
  # print(len(score_x_id_ord))
  for score in score_x_id_ord[-10:]:
    print('"',score[-1],'" tiene un score promedio de',score[1])
  print('\n')
  print('Los productos que no tienen reseña son: \n')
  for score in sin_score:
    print('"',score[-1],'" ',score[1])
  print('\n')
  print('Para ver los productos con mas problemas, tome en cuenta si estan abajo del score promedio de todos los productos y si tuvieron devoluciones: \n')
  for score in worst_score:
    print('"',score[-1],'" tiene un score promedio de',score[1],'y tiene',score[2],'devoluciones')
  print('\n')

elif opcion == '3':
  print('\n')
  for venta in venta_x_mes:
    print('Para el mes ', venta[0],', tiene ', venta[1],'ventas y sus ingresos son $', venta[2])
  print('\n') 
  print('Los meses con mas ventas son 4, 1 y 3') 
  print('La venta anual es $',venta_anual)

else:
  print('No es una opción correcta, vuelve a intentarlo')
