from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

# Hago una copia de "lifestore_products" para no modificar la lista original
lifestore_products_copy =[]
for item in lifestore_products: 
  lifestore_products_copy.append(item)

# print(lifestore_products_copy)

# Obtengo una lista con los ID de los productos
id_product=[]
categoria=[]

for id in range(len(lifestore_products_copy)):
  id_product.append(lifestore_products_copy[id][0])
  categoria.append(lifestore_products_copy[id][3])     

#-----------------------------------------------------
# 1.1.- Generar un listado de los 50 productos con mayores ventas y uno con los 100 productos con mayor búsquedas.

# Obtengo cuantas veces se vendio cada producto
venta_x_id=[]
for producto in id_product:
    n_venta=0
    for id in range(len(lifestore_sales)):
        if producto == lifestore_sales[id][1]:
            n_venta+=1
    # Armo venta con producto y n_venta, y lo agrego en una nueva lista "venta_x_id"
    venta = [producto,n_venta]
    venta_x_id.append(venta)

# print(venta_x_id)

# Ordenar la lista 'venta_x_id' por ventas de manera descendiente

venta_x_id_ord=[]
# venta_x_id_ord1=[]
j=0

while venta_x_id:
    maxi = venta_x_id[0][1]
    lista = venta_x_id[0]
    for venta in venta_x_id:
      if venta[1] > maxi:
        maxi = venta[1]
        lista = venta
    venta_x_id_ord.append(lista)
    venta_x_id.remove(lista)

# print(venta_x_id_ord)

# Hacemos match con el id_product en "lifestore_products" para obtener los 20 productos mas vendidos

top_ventas=[]

# for venta in venta_x_id_ord:
#   # print(venta)
#   for id in range(len(lifestore_products)):
#     if venta[0] == lifestore_products[id][0]:
#       lifestore_products[id].append(venta[1])
#       # print(lifestore_products[id])
#       top_ventas.append(lifestore_products[id])

#El codigo anterior modifica la lista "lifestore_products", mi intención es tener una lista independiente de "top_ventas" y "top_busqueda" y no modificar "lifestore_products"

for venta in venta_x_id_ord:
  # print(venta)
  for id in range(len(lifestore_products_copy)):
    if venta[0] == lifestore_products_copy[id][0]:
      # lifestore_products[id].append(venta[1])
      # print(lifestore_products[id])
      top_ventas.append(lifestore_products_copy[id])
      top_ventas[-1].append(venta[1])

#Aunque no lo logre :(

# print(top_ventas)
# print(len(top_ventas))

# Repito el codigo para obtener las ventas 
# adaptandolo para las busquedas
busquedas_x_id=[]
for producto in id_product:
    n_busqueda=0
    for id in range(len(lifestore_searches)):
        if producto == lifestore_searches[id][1]:
            n_busqueda+=1
    # Armo 'busqueda' con producto y n_busqueda, y lo agrego en una nueva lista "_x_id"
    busqueda = [producto,n_busqueda]
    busquedas_x_id.append(busqueda)

# print(busquedas_x_id)

# Ordenar la lista 'busquedas_x_id' por busquedas de manera descendiente

busquedas_x_id_ord=[]

while busquedas_x_id:
    maxi = busquedas_x_id[0][1]
    lista = busquedas_x_id[0]
    for busqueda in busquedas_x_id:
      if busqueda[1] > maxi:
        maxi = busqueda[1]
        lista = busqueda
    busquedas_x_id_ord.append(lista)
    busquedas_x_id.remove(lista)

# print(busquedas_x_id_ord)

# Hacemos match con el id_product en "lifestore_products" para obtener los 20 productos mas buscados

top_busqueda=[]

# for busqueda in busquedas_x_id_ord:
#   # print(venta)
#   for id in range(len(lifestore_products)):
#     if busqueda[0] == lifestore_products[id][0]:
#       lifestore_products[id].append(busqueda[1])
#       # print(lifestore_products[id])
#       top_busqueda.append(lifestore_products[id])
#       # print(top_busqueda[-1])

#El codigo anterior modifica la lista "lifestore_products", mi intención es tener una lista independiente de "top_ventas" y "top_busqueda"

for busqueda in busquedas_x_id_ord:
  # print(venta)
  for id in range(len(lifestore_products_copy)):
    if busqueda[0] == lifestore_products_copy[id][0]:
      # lifestore_products[id].append(busqueda[1])
      # print(lifestore_products[id])
      top_busqueda.append(lifestore_products_copy[id])
      top_busqueda[-1].append(busqueda[1])
      # print(top_busqueda[-1])

# print(top_busqueda)

#----------------------------------------------------
# 1.2.- Por categoría, generar un listado con los 50 productos con menores ventas y uno con los 100 productos con menores búsquedas.

#Eliminamos los duplicados para obtener un catalogo de las categorias de la tienda

catalogo_cat = [] 
for i in categoria: 
    if i not in catalogo_cat: 
        catalogo_cat.append(i) 

# print(catalogo_cat)

# Hago una lista para agregar las ventas por categoria y las busquedas por categoria
venta_x_cat =[]
busqueda_x_cat =[]
for cat in catalogo_cat: 
  venta_x_cat.append(cat)
  busqueda_x_cat.append(cat) 

# print(busqueda_x_cat) 

# Agrupo los articulos por categoria de la lista "top_ventas", aprovecho que ya estan ordenados por ventas para obtener los productos mas vendidos por categoria 
for i in range(len(venta_x_cat)):
  cat=venta_x_cat[i]
  venta_x_cat[i]=[]

  for id in range(len(top_ventas)):
      if cat == top_ventas[id][3]:
          # print(top_ventas[id])
          venta_x_cat[i].append(top_ventas[id])

# print(catalogo_cat)
# print(venta_x_cat)
# print(len(venta_x_cat))

# Hago un procedimiento similar para obtener las busquedas por categoria

for i in range(len(busqueda_x_cat)):
  cat=busqueda_x_cat[i]
  busqueda_x_cat[i]=[]

  for id in range(len(top_busqueda)):
      if cat == top_busqueda[id][3]:
          # print(top_ventas[id])
          busqueda_x_cat[i].append(top_busqueda[id])

# print(busqueda_x_cat[0])
# print(len(busqueda_x_cat[0]))
# print(lifestore_products_copy[0])

#  print(top_ventas[:5])
# print(venta_x_id_ord)

# print(top_busqueda[:5])
# print(busquedas_x_id_ord)

#-------------------------------------------------------

# 2.- Productos por reseña en el servicio

# Agrupo el score que obtuvo cada producto y obtengo el promedio del score por producto

score_x_id=[]
sin_score=[]

for producto in id_product:
    n_score=0
    s_score=0
    n_refund=0
    for id in range(len(lifestore_sales)):
        if producto == lifestore_sales[id][1]:
            n_score+=1
            s_score+=lifestore_sales[id][2]
            n_refund+=lifestore_sales[id][-1]
    # Si no hay score (n_score=0), no se puede calcular el promedio, pero los agrupo para analizar como es su venta
    if n_score == 0:
      prom_score = "no tiene score"
      score = [producto,prom_score]
      sin_score.append(score)
    # Armo score con producto y score_prom=s_score/n_venta, y lo agrego en una nueva lista "score_x_id"
    else:
      prom_score=s_score/n_score
      score = [producto,prom_score,n_refund]
      score_x_id.append(score)
    # print(score)

# print(score_x_id)
# print(sin_score)

# Ordeno la lista de acuerdo al score dado
score_x_id_ord=[]
while score_x_id:
    maxi = score_x_id[0][1]
    lista = score_x_id[0]
    for score in score_x_id:
      if score[1] > maxi:
        maxi = score[1]
        lista = score
    score_x_id_ord.append(lista)
    score_x_id.remove(lista)

# print(score_x_id_ord[-10:])
# print(score_x_id)

# Agrego el nombre del producto a la lista 'sin_score'
for score in sin_score:
  for id in range(len(lifestore_products)):
    if score[0] == lifestore_products[id][0]:
      score.append(lifestore_products[id][1])

# print(sin_score)

# Agrego el nombre del producto a la lista 'score_x_id_ord'
for score in score_x_id_ord:
  for id in range(len(lifestore_products)):
    if score[0] == lifestore_products[id][0]:
      score.append(lifestore_products[id][1])

# print(score_x_id_ord)


# Obtengo el promedio del score de todos los productos
n_score_total=len(score_x_id_ord)
s_score_total=0

for id in range(len(score_x_id_ord)):
    # n_score+=1
    s_score_total+=score_x_id_ord[id][1]
    # print(s_score_total)

prom_score_total=s_score_total/n_score_total
# print(prom_score_total)           


# Obtengo la lista de los articulos con menor score y que tengan una devolución o mas 
worst_score=[]

for score in score_x_id_ord:
  if score[-2] > 0 and score[1] < prom_score_total:
    worst_score.append(score)

# print(worst_score)

#---------------------------------------------------
# 3.- Total de ingresos y ventas promedio mensuales, total anual y meses con más ventas al año

# i=3
# a = lifestore_sales[i][3]
# print(lifestore_sales[i])
# print(a[3:5])
# print(a[-4:])

# Obtengo el mes y año de la compra, y las agrego como dos nuevas columnas 
mes = []
año = []
for id in lifestore_sales:
  a = id[3]
  # print(a)
  id.append(int(a[3:5]))
  mes.append(id[-1])
  id.append(int(a[-4:]))
  año.append(id[-1])
  # print(id)

# print(mes)
# print(año)

#Eliminamos los duplicados del mes
mes_lim = []
for i in mes: 
    if i not in mes_lim: 
        mes_lim.append(i) 
# print(mes_lim)

#Eliminamos los duplicados del año
año_lim = []
for i in año: 
    if i not in año_lim: 
        año_lim.append(i)
# print(año_lim)

# Al observar los meses me di cuenta que habia ventas del 2019 y 2020, al obtener la columna de "año", me di cuenta que hay una venta del 2002

# for i in lifestore_sales:
#   # print(i)
#   if i[-1]==2002:
#     print(i)

# seguramente es un error de captura, pero es importante tenerlo en cuenta para corregirlo o para tener un analisis preciso, y no solo agruparlo por meses

# Hago una nueva lista para tener ordenado de manera ascendente los meses
catalogo_mes=[]
while mes_lim:
    mini = mes_lim[0]
    lista = mes_lim[0]
    for mes in mes_lim:
      if mes < mini:
        mini = mes
        lista = mes
    catalogo_mes.append(lista)
    mes_lim.remove(lista)
# print(catalogo_mes)

# Agrupo las ventas por año de la lista "lifestore_sales"
for i in range(len(año_lim)):
  año=año_lim[i]
  año_lim[i]=[]

  for id in range(len(lifestore_sales)):
      if año == lifestore_sales[id][-1]:
          # print(lifestore_sales[id])
          año_lim[i].append(lifestore_sales[id])

# print(año_lim[0])
# print(año_lim[1])
# print(len(venta_x_mes))

# Selecciono la lista donde estan las ventas del 2020, año_lim[0], para agregar el precio del producto

año_sale=año_lim[0]

for i in range(len(año_sale)):
  id_product=año_sale[i][1]
  # print(año_sale[i])

  for id in range(len(lifestore_products)):
      if id_product == lifestore_products[id][0]:
        # print(mes)
        precio=lifestore_products[id][2]
        # print([id_product,precio])
        año_sale[i].append(precio)
  # print(año_sale[i])

# print(año_sale)
# print(año_sale[0])

# Ya que tengo el precio del producto, se puede obtener las ventas por mes del año 2020 y la venta total anual

venta_x_mes=[]
for i in range(len(catalogo_mes)):
  mes=catalogo_mes[i]
  catalogo_mes[i]=[]
  n_venta=0
  # s_venta=0

  for id in range(len(año_sale)):
      if mes == año_sale[id][-3]:
        # print(mes)
        # print(año_sale[id])
        n_venta+=1
        # s_venta+=
      precio=año_sale[id][-1]
      venta=n_venta*precio
      venta_mes=[mes, n_venta,venta]
  # print(venta_mes)
  venta_x_mes.append(venta_mes)
  
# print(venta_x_mes)
# print(lifestore_products)

# Calculamos la venta anual
venta_anual=0
for venta in venta_x_mes:
  # print(venta)
  venta_anual+=venta[2]

# print(venta_anual)